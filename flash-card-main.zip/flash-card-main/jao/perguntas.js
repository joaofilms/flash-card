criaCartao(
    'Quem Sou Eu?',
    '',
    'Sou um jovem de 16 anos, estudo na 2b, trabalho como vendedor.'
)

criaCartao(
    'Minha família é',
    '',
    'Minha família é grande, gosta de se reunir e fazer churrasco'
)

criaCartao(
    'minha casa',
    '',
    'Moro em uma casa cinza perto de uma oficina, com 4 pessoas.'
)

criaCartao(
    'Minha Turma',
    '',
    'bastante imperativa mas determinada, somos em 33 alunos segundo a representante.'
)

criaCartao(
    'Faculdade',
    '',
    'pretendo fazer agronomia, gosto de estudar sobre plantas, solos e etc.'
)

criaCartao(
    'Minha Cidade',
    '',
    'a cidade onde eu moro contém muitas rotulas, cachorros, mas fora isso é uma cidade tranquila e organizada.'
)

criaCartao(
    'Sonho',
    '',
    'Sonho em conquistar uma profissão digna para poder viajar pelo mundo, formar minha família e dar orgulho a meus pais.'
)

criaCartao(
    'profissão',
    '',
    'minha profissao é vendedor de aparelhos eletronicos'
)